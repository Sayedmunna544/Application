package uk.ac.tees.mad.petcaretracker

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class PetCareTrackerApplication : Application() {
}